#!/usr/bin/env python

import boto3, os
from datetime import datetime, timedelta

# Set and format today's date
today = datetime.now()

# Create EC2 client
ec2 = boto3.client('ec2')

# Set filters from user input
filters = [{'Name':os.environ['filter_key'], 'Values':[os.environ['filter_val']]}]

# Get a list of images based on search filters
image_list = ec2.describe_images(Owners=['self'],Filters=filters)

# Look through the list for dates, image ids
for image in image_list['Images']:
    # Set values for later use
    create_date = image['CreationDate']
    create_date = create_date.split('T')[0]
    image_id = image['ImageId']
    create_date = datetime.strptime(create_date, '%Y-%m-%d')
    # Check for matches that are older than 'exp_days', and deregister
    if today - timedelta(days=int(os.environ['exp_days'])) > create_date:
        ec2.deregister_image(ImageId=image_id)